import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ASMAN Trade Connect | Verified Africa-to-Global Trade",
  description: "A verified trade intelligence and procurement network connecting qualified African suppliers with global buyers and logistics providers.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
