"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { ArrowLeft, CheckCircle2, Loader2, ShieldCheck } from "lucide-react";
import { supabase } from "@/lib/supabase";

type AccountType = "buyer" | "supplier" | "contributor" | "logistics";

export default function AuthPage() {
  const [mode, setMode] = useState<"signup" | "signin">("signup");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true); setMessage("");
    const form = new FormData(event.currentTarget);
    const email = String(form.get("email") || "");
    const password = String(form.get("password") || "");
    if (!supabase) { setMessage("Account services are temporarily unavailable."); setLoading(false); return; }
    if (mode === "signin") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) setMessage(error.message); else location.href = "/dashboard";
    } else {
      const accountType = String(form.get("accountType") || "buyer") as AccountType;
      const { error } = await supabase.auth.signUp({ email, password, options: { data: {
        full_name: String(form.get("fullName") || ""), phone: String(form.get("phone") || ""),
        country: String(form.get("country") || ""), account_type: accountType,
      }}});
      setMessage(error ? error.message : "Account created. Check your email to confirm your registration.");
    }
    setLoading(false);
  }

  return <main className="auth-shell">
    <section className="auth-context">
      <Link href="/" className="back-link"><ArrowLeft size={17}/> Back to platform</Link>
      <div><p className="eyebrow">ASMAN TRADE CONNECT</p><h1>Enter the network with a verified business identity.</h1><p>Your account type determines the information, opportunities and transaction tools available in your workspace.</p><ul><li><CheckCircle2/> Structured company and trade profiles</li><li><CheckCircle2/> Controlled submissions and human review</li><li><CheckCircle2/> Role-specific opportunities and workflows</li></ul></div>
      <p className="auth-security"><ShieldCheck/> Administrator access cannot be selected during registration.</p>
    </section>
    <section className="auth-panel"><div className="auth-card">
      <div className="auth-tabs"><button className={mode === "signup" ? "active" : ""} onClick={() => {setMode("signup"); setMessage("");}}>Create account</button><button className={mode === "signin" ? "active" : ""} onClick={() => {setMode("signin"); setMessage("");}}>Sign in</button></div>
      <h2>{mode === "signup" ? "Create your trade account" : "Welcome back"}</h2><p>{mode === "signup" ? "Use accurate information. Business evidence is reviewed separately." : "Sign in to continue to your workspace."}</p>
      <form onSubmit={submit}>{mode === "signup" && <><label>Account type<select name="accountType" required defaultValue="buyer"><option value="buyer">Buyer / Importer</option><option value="supplier">Supplier / Exporter</option><option value="contributor">Market Price Contributor</option><option value="logistics">Logistics Provider</option></select></label><label>Full name<input name="fullName" required autoComplete="name" /></label><div className="field-row"><label>Country<input name="country" required /></label><label>Phone<input name="phone" type="tel" autoComplete="tel" /></label></div></>}<label>Email address<input name="email" type="email" required autoComplete="email" /></label><label>Password<input name="password" type="password" required minLength={8} autoComplete={mode === "signup" ? "new-password" : "current-password"} /></label><button className="burgundy-button auth-submit" disabled={loading}>{loading && <Loader2 className="spin" size={17}/>} {mode === "signup" ? "Create account" : "Sign in"}</button></form>
      {message && <p className="auth-message" role="status">{message}</p>}<small>By creating an account, you agree to provide accurate trade and company information. Verification is not automatic.</small>
    </div></section>
  </main>;
}
